Répartiteur local de classes
============================

1. Ouvrir index.html dans un navigateur récent (Chrome, Edge, Firefox).
2. Charger la liste des futurs élèves.
3. Charger éventuellement le fichier des résultats / punitions / sanctions.
4. Vérifier les colonnes détectées automatiquement.
5. Modifier les quotas et contraintes si besoin.
6. Cliquer sur "Créer une répartition", puis sur "Exporter Excel".

Confidentialité
---------------
Les fichiers sont lus localement dans le navigateur. Cette page n'envoie pas les noms ou les données à ChatGPT ni à un serveur.

Important pour un usage 100 % hors connexion
--------------------------------------------
Cette version utilise la bibliothèque SheetJS pour lire et écrire les fichiers Excel/ODS.
- Si le fichier xlsx.full.min.js est placé dans le même dossier que index.html, tout fonctionne hors connexion.
- Sinon, le navigateur peut charger cette bibliothèque depuis Internet. Les tableurs restent tout de même traités localement.

Syntaxe des contraintes
-----------------------
ENSEMBLE: Nom Prenom; Nom Prenom
SEPARER: Nom Prenom; Nom Prenom; Nom Prenom
CLASSE 5e3: Nom Prenom; Nom Prenom
AVEC_UN: Nom Prenom | Choix 1; Choix 2

Exemple de quotas
-----------------
5e1: alld=9; latin=7
5e2: alld=9; latin=7
5e3: latin=7; effectif=27
