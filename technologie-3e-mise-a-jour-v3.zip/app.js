'use strict';
function safeURL(value, base) {
  if (/^(?:javascript|data|vbscript):/i.test(value)) return null;
  try { const u = new URL(value, base); return ['https:', 'http:', 'file:'].includes(u.protocol) ? u.href : null; } catch { return null; }
}
function videoID(value) {
  try {const u=new URL(value);let id=null;const h=u.hostname.toLowerCase();if(h==='youtu.be')id=u.pathname.split('/')[1];else if(['youtube.com','www.youtube.com','m.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'].includes(h)){id=u.searchParams.get('v');if(!id&&/^\/(shorts|embed|live)\//.test(u.pathname))id=u.pathname.split('/')[2];}return /^[\w-]{11}$/.test(id||'')?id:null;}catch{return null;}
}
function parseContent(text,base) {
 const sequences=[],errors=[];let seq=null,act=null;
 text.replace(/^\uFEFF/,'').split(/\r?\n/).forEach((raw,index)=>{const line=raw.trim();if(!line||line.startsWith('//'))return;
 const bad=message=>errors.push(`Ligne ${index+1} : ${message}`);
 if(line.startsWith('## ')){if(!seq)return bad('ajoute une séquence (# Titre) avant cette activité.');act={title:line.slice(3).trim(),description:[],links:[]};seq.activities.push(act);return;}
 if(line.startsWith('# ')){seq={title:line.slice(2).trim(),description:[],activities:[]};sequences.push(seq);act=null;return;}
 if(line.startsWith('#'))return bad('utilise # suivi d’un espace pour une séquence, ou ## suivi d’un espace pour une activité.');
 if(line.includes('|')){if(!act)return bad('place ce lien sous une activité (## Titre).');const parts=line.split('|').map(s=>s.trim());if(parts.length!==3||parts.some(s=>!s))return bad('format attendu : PDF | Nom du bouton | adresse');const[type,label,path]=parts;const kind=type.toUpperCase();if(!['PDF','WEB','VIDEO','LIEN'].includes(kind))return bad('type inconnu : utilise PDF, WEB, VIDEO ou LIEN.');const url=safeURL(path,base);if(!url)return bad('adresse non autorisée ou invalide.');const id=kind==='VIDEO'?videoID(url):null;if(kind==='VIDEO'&&!id)return bad('utilise le lien YouTube d’une vidéo (watch, youtu.be, shorts ou live).');act.links.push({type:kind,label,url,id});return;}
 if(!seq)return bad('place le texte sous une séquence.');(act||seq).description.push(line);
 });return {sequences,errors};
}
if(typeof module!=='undefined')module.exports={parseContent,videoID,safeURL};
if(typeof document!=='undefined'){
const $=id=>document.getElementById(id);let data={sequences:[],errors:[]};let treeReady=false;
const palettes=[['#356bd0','#eaf1ff'],['#098478','#def6ef'],['#8150bb','#f0e9fb'],['#bd6a22','#fff0dc'],['#c24870','#fce8ef'],['#257d9e','#e0f3fa']];
const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;return e;};
function color(e,i){const p=palettes[i%palettes.length];e.style.setProperty('--accent',p[0]);e.style.setProperty('--tint',p[1]);}
function icon(type){const paths={PDF:'<path d="M20 8h27l13 13v43H20z"/><path d="M46 8v15h14M29 34h22M29 43h22M29 52h14"/>',WEB:'<rect x="8" y="13" width="64" height="46" rx="5"/><path d="M8 26h64M15 20h1m6 0h1m6 0h1M30 36l-8 7 8 7m20-14 8 7-8 7M43 33l-6 20"/>',LIEN:'<path d="M33 46l14-14M28 36l-7 7a12 12 0 0017 17l10-10M52 44l7-7a12 12 0 00-17-17L32 30"/>',ACT:'<rect x="13" y="17" width="54" height="49" rx="6"/><path d="M28 17v-6h24v6M26 32h28M26 43h18M26 54h23"/>'};const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 80 80');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','3');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');svg.innerHTML=paths[type]||paths.LIEN;return svg;}
function closeVideo(){if($('video').open)$('video').close();$('player').replaceChildren();}
$('close-video').onclick=closeVideo;$('video').addEventListener('close',()=> $('player').replaceChildren());$('video').addEventListener('click',e=>{if(e.target===$('video')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeVideo();}});
function play(link){$('video-title').textContent=link.label;$('youtube-link').href=link.url;const f=el('iframe');f.title=link.label;f.src=`https://www.youtube-nocookie.com/embed/${link.id}?rel=0`;f.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';f.allowFullscreen=true;f.referrerPolicy='strict-origin-when-cross-origin';$('player').replaceChildren(f);$('video').showModal();}
function headingParts(title,type,number){
 const re=type==='SEQ'?/^séquence\s*(\d+)\s*(?:[—–:.-]\s*)?(.*)$/i:/^activité\s*(\d+)\s*(?:[—–:.-]\s*)?(.*)$/i;
 const m=title.match(re);
 if(m)return {label:`${type==='SEQ'?'Séquence':'Activité'} ${m[1]}`,title:m[2].trim()};
 if(type==='ACT'&&/^(synthèses?|corrections?|évaluations?|ressources|documents|bilan|pour aller plus loin)\b/i.test(title))return {label:title,title:''};
 return {label:`${type==='SEQ'?'Séquence':'Activité'} ${number}`,title};
}
function card({title,href,index=0,type,number,meta='',link}){
 const video=type==='VIDEO',group=type==='SEQ'||type==='ACT';const c=el(video?'button':'a',null,'card '+(group?'group-card':'resource-card'));color(c,index);
 if(video){c.type='button';c.onclick=()=>play(link);}else{c.href=href;if(link){c.target='_blank';c.rel='noopener noreferrer';}}
 const visual=el('div',null,'visual');let displayTitle=title;
 if(group){const parts=headingParts(title,type,number);visual.append(el('span',parts.label,'group-label'));displayTitle=parts.title;}
 else if(video){const img=el('img',null,'video-thumb');img.alt='';img.loading='lazy';img.src=`https://i.ytimg.com/vi/${link.id}/hqdefault.jpg`;img.onerror=()=>img.remove();visual.append(img,el('span','▶','play-mark'));}
 else {visual.append(icon(type==='LIEN'?'WEB':type));if(type==='PDF')visual.append(el('span','PDF','pdf-mark'));}
 const body=el('div',null,'card-body');if(displayTitle)body.append(el('h2',displayTitle));
 if(type==='ACT')body.append(el('div',meta,'resource-count'));
 c.append(visual,body);return c;
}
function buildTree(){const tree=$('tree');tree.replaceChildren();data.sequences.forEach((s,i)=>{
 const d=el('section',null,'tree-seq');color(d,i);d.dataset.sequence=i;
 const row=el('div',null,'tree-row'),toggle=el('button','›','tree-toggle'),name=el('a',s.title,'tree-name'),children=el('div',null,'tree-children');
 children.id=`tree-children-${i}`;children.hidden=true;toggle.type='button';toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-controls',children.id);toggle.setAttribute('aria-label',`Déplier ou replier ${s.title}`);
 toggle.onclick=()=>{children.hidden=!children.hidden;toggle.setAttribute('aria-expanded',String(!children.hidden));};name.href=`#sequence-${i+1}`;
 name.onclick=()=>{children.hidden=false;toggle.setAttribute('aria-expanded','true');};row.append(toggle,name);d.append(row,children);
 s.activities.forEach((a,j)=>{const link=el('a',a.title);link.href=`#sequence-${i+1}-activite-${j+1}`;children.append(link);});tree.append(d);
 });treeReady=true;}
function crumb(text,href){const e=el(href===null?'span':'a',text);if(href!==null)e.href=href;$('breadcrumb').append(e);}
function render(focus=false){closeVideo();if(!treeReady)buildTree();const m=location.hash.match(/^#sequence-(\d+)(?:-activite-(\d+))?$/);const si=m?Number(m[1])-1:-1,seq=data.sequences[si],ai=m&&m[2]?Number(m[2])-1:-1,act=seq?.activities[ai];$('content').replaceChildren();$('breadcrumb').replaceChildren();$('content').className=act?'grid resources':'grid';crumb('Accueil',seq?'#':null);if(seq){crumb('›',null);crumb(seq.title,act?`#sequence-${si+1}`:null);}if(act){crumb('›',null);crumb(act.title,null);}
$('title').textContent=act?.title||seq?.title||'Mes séquences';const description=(act||seq)?.description.join('\n')||'';$('description').textContent=description;$('description').hidden=!description;
$('tree').querySelectorAll('a').forEach(a=>{if(a.getAttribute('href')===location.hash)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});if(seq){const d=$('tree').querySelector(`[data-sequence="${si}"]`);if(d){d.querySelector('.tree-children').hidden=false;d.querySelector('.tree-toggle').setAttribute('aria-expanded','true');}}
if(act)act.links.forEach(link=>{const types={PDF:['PDF',0],WEB:['ACTIVITÉ EN LIGNE',1],VIDEO:['VIDÉO',4],LIEN:['LIEN',2]};const [meta,index]=types[link.type];$('content').append(card({title:link.label,href:link.url,type:link.type,meta,index,link}));});
else if(seq)seq.activities.forEach((a,i)=>$('content').append(card({title:a.title,description:a.description.join('\n'),href:`#sequence-${si+1}-activite-${i+1}`,type:'ACT',number:i+1,index:si,meta:`${a.links.length} ressource${a.links.length>1?'s':''}`})));
else data.sequences.forEach((s,i)=>$('content').append(card({title:s.title,description:s.description.join('\n'),href:`#sequence-${i+1}`,type:'SEQ',number:i+1,index:i,meta:`${s.activities.length} rubrique${s.activities.length>1?'s':''}`})));
if(!$('content').children.length)$('content').append(el('p',act?'Ressources à venir.':seq?'Activités à venir.':'Séquences à venir.','empty'));if(focus){$('title').focus();window.scrollTo(0,0);}}
function load(text){data=parseContent(text,location.href);treeReady=false;$('notice').replaceChildren();if(data.errors.length){const d=el('details',null,'warning');d.append(el('summary',`${data.errors.length} ligne(s) de contenu.txt à corriger`));data.errors.forEach(x=>d.append(el('p',x)));$('notice').append(d);}render();}
window.addEventListener('hashchange',()=>render(true));$('file').addEventListener('change',async e=>{if(e.target.files[0])load(await e.target.files[0].text());});
if(location.protocol==='file:'){$('local').hidden=false;load('');}else fetch('contenu.txt',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error(r.status);return r.text();}).then(load).catch(()=>{$('content').replaceChildren(el('p','Impossible de charger contenu.txt. Vérifie sa présence à côté de index.html.','warning'));$('local').hidden=false;});
}
