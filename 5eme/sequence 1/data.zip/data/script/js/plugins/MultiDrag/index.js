export { default } from './MultiDrag.js';
